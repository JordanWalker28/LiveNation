﻿namespace RuleResponseGenerator
{
    public class EmptyRule
    {
        public string Run(double number) {
            return number.ToString();
        }
    }
}
