﻿namespace RuleResponseGenerator
{
    public interface IRule
    {
        string Run(double number);
    }
}