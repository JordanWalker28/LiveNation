﻿namespace RuleResponseGenerator
{
    public interface ICreateInputResponse
    {
        string GenerateRespone(int v1, int v2);
    }
}