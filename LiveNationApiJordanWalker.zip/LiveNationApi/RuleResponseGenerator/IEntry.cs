﻿namespace RuleResponseGenerator
{
    public interface IEntry
    {
        Response CreateResponse(string arg);
    }
}